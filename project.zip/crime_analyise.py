import pandas as pd
import matplotlib.pyplot as plt
import os

CRIME_FILE = "crime_records.csv"
FIR_FILE = "fir_records.csv"
CASE_FILE = "case_tracking.csv"
EVIDENCE_FILE = "evidence_records.csv"


# ---------------- Crime Graphs ----------------
def crime_graph():

    if os.path.exists(CRIME_FILE):

        df = pd.read_csv(CRIME_FILE)

        if df.empty:
            print("No Crime Records")
            return

        # Bar Chart
        plt.figure(figsize=(6,4))
        df["Crime"].value_counts().plot(kind="bar")
        plt.title("Crime Type Report")
        plt.xlabel("Crime Type")
        plt.ylabel("Number of Crimes")
        plt.grid()
        plt.show()

        # Pie Chart
        plt.figure(figsize=(6,6))
        df["Crime"].value_counts().plot(kind="pie", autopct="%1.1f%%")
        plt.title("Crime Distribution")
        plt.ylabel("")
        plt.show()

        # Histogram
        plt.figure(figsize=(6,4))
        df["Age"].plot(kind="hist", bins=8)
        plt.title("Age Distribution of Criminals")
        plt.xlabel("Age")
        plt.ylabel("Frequency")
        plt.grid()
        plt.show()

    else:
        print("crime_records.csv Not Found")


# ---------------- FIR Graphs ----------------
def fir_graph():

    if os.path.exists(FIR_FILE):

        df = pd.read_csv(FIR_FILE)

        if df.empty:
            print("No FIR Records")
            return

        plt.figure(figsize=(6,4))
        df["Status"].value_counts().plot(kind="bar")
        plt.title("FIR Status")
        plt.show()

        plt.figure(figsize=(6,6))
        df["Status"].value_counts().plot(kind="pie", autopct="%1.1f%%")
        plt.title("FIR Status Distribution")
        plt.ylabel("")
        plt.show()

    else:
        print("fir_records.csv Not Found")


# ---------------- Case Graphs ----------------
def case_graph():

    if os.path.exists(CASE_FILE):

        df = pd.read_csv(CASE_FILE)

        if df.empty:
            print("No Case Records")
            return

        plt.figure(figsize=(6,4))
        df["Status"].value_counts().plot(kind="bar")
        plt.title("Case Status")
        plt.show()

        plt.figure(figsize=(6,6))
        df["Status"].value_counts().plot(kind="pie", autopct="%1.1f%%")
        plt.title("Case Distribution")
        plt.ylabel("")
        plt.show()

    else:
        print("case_tracking.csv Not Found")


# ---------------- Evidence Graphs ----------------
def evidence_graph():

    if os.path.exists(EVIDENCE_FILE):

        df = pd.read_csv(EVIDENCE_FILE)

        if df.empty:
            print("No Evidence Records")
            return

        plt.figure(figsize=(6,4))
        df["Status"].value_counts().plot(kind="bar")
        plt.title("Evidence Status")
        plt.show()

        plt.figure(figsize=(6,6))
        df["Status"].value_counts().plot(kind="pie", autopct="%1.1f%%")
        plt.title("Evidence Distribution")
        plt.ylabel("")
        plt.show()

    else:
        print("evidence_records.csv Not Found")


# ---------------- Menu ----------------
def report_menu():

    while True:

        print("\n========== REPORTS ==========")
        print("1. Crime Graphs")
        print("2. FIR Graphs")
        print("3. Case Graphs")
        print("4. Evidence Graphs")
        print("5. All Graphs")
        print("6. Exit")

        ch = input("Enter Choice: ")

        if ch == "1":
            crime_graph()

        elif ch == "2":
            fir_graph()

        elif ch == "3":
            case_graph()

        elif ch == "4":
            evidence_graph()

        elif ch == "5":
            crime_graph()
            fir_graph()
            case_graph()
            evidence_graph()

        elif ch == "6":
            print("Returning...")
            break

        else:
            print("Invalid Choice")


if __name__ == "__main__":
    report_menu()