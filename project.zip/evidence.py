import csv
import os

FILE = "evidence_records.csv"

# ---------- Create File ----------
def create_file():
    if not os.path.exists(FILE):
        with open(FILE, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow([
                "Evidence ID",
                "Case ID",
                "Evidence Type",
                "Description",
                "Collected By",
                "Status"
            ])


# ---------- Add Evidence ----------
def add_evidence():

    create_file()

    evidence_id = input("Evidence ID: ")
    case_id = input("Case ID: ")
    evidence_type = input("Evidence Type: ")
    description = input("Description: ")
    collected_by = input("Collected By: ")
    status = input("Status (Pending/Stored/Submitted): ")

    with open(FILE, "a", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            evidence_id,
            case_id,
            evidence_type,
            description,
            collected_by,
            status
        ])

    print("Evidence Added Successfully")


# ---------- View Evidence ----------
def view_evidence():

    create_file()

    with open(FILE, "r") as f:
        reader = csv.reader(f)

        print("\n========== EVIDENCE RECORDS ==========\n")

        for row in reader:
            print(row)


# ---------- Search Evidence ----------
def search_evidence():

    create_file()

    evidence_id = input("Enter Evidence ID: ")

    with open(FILE, "r") as f:

        reader = csv.reader(f)

        next(reader)

        for row in reader:

            if row[0] == evidence_id:
                print("\nRecord Found")
                print(row)
                return

    print("Evidence Not Found")


# ---------- Update Evidence ----------
def update_evidence():

    create_file()

    evidence_id = input("Enter Evidence ID: ")

    rows = []

    found = False

    with open(FILE, "r") as f:

        reader = csv.reader(f)

        header = next(reader)

        for row in reader:

            if row[0] == evidence_id:

                row[2] = input("New Evidence Type: ")
                row[3] = input("New Description: ")
                row[4] = input("Collected By: ")
                row[5] = input("New Status: ")

                found = True

            rows.append(row)

    with open(FILE, "w", newline="") as f:

        writer = csv.writer(f)

        writer.writerow(header)
        writer.writerows(rows)

    if found:
        print("Evidence Updated Successfully")
    else:
        print("Evidence ID Not Found")


# ---------- Delete Evidence ----------
def delete_evidence():

    create_file()

    evidence_id = input("Enter Evidence ID: ")

    rows = []

    found = False

    with open(FILE, "r") as f:

        reader = csv.reader(f)

        header = next(reader)

        for row in reader:

            if row[0] != evidence_id:
                rows.append(row)
            else:
                found = True

    with open(FILE, "w", newline="") as f:

        writer = csv.writer(f)

        writer.writerow(header)
        writer.writerows(rows)

    if found:
        print("Evidence Deleted Successfully")
    else:
        print("Evidence ID Not Found")


# ---------- Pending Evidence (List Comprehension) ----------
def pending_evidence():

    create_file()

    with open(FILE, "r") as f:

        reader = csv.reader(f)

        next(reader)

        pending = [row for row in reader if row[5].lower() == "pending"]

    print("\nPending Evidence")

    if pending:
        for row in pending:
            print(row)
    else:
        print("No Pending Evidence")


# ---------- Sort Evidence (Lambda) ----------
def sort_evidence():

    create_file()

    with open(FILE, "r") as f:

        reader = csv.reader(f)

        header = next(reader)

        rows = list(reader)

    rows.sort(key=lambda x: x[2].lower())

    print("\nSorted Evidence\n")
    print(header)

    for row in rows:
        print(row)


# ---------- Evidence Menu ----------
def evidence_menu():

    create_file()

    while True:

        print("\n========== EVIDENCE MANAGEMENT ==========")
        print("1. Add Evidence")
        print("2. View Evidence")
        print("3. Search Evidence")
        print("4. Update Evidence")
        print("5. Delete Evidence")
        print("6. Pending Evidence")
        print("7. Sort Evidence")
        print("8. Back")

        choice = input("Enter Choice: ")

        if choice == "1":
            add_evidence()

        elif choice == "2":
            view_evidence()

        elif choice == "3":
            search_evidence()

        elif choice == "4":
            update_evidence()

        elif choice == "5":
            delete_evidence()

        elif choice == "6":
            pending_evidence()

        elif choice == "7":
            sort_evidence()

        elif choice == "8":
            print("Returning to Main Menu...")
            break

        else:
            print("Invalid Choice")


# ---------- Run File ----------
if __name__ == "__main__":
    evidence_menu()