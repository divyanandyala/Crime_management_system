import csv
import os

FILE = "fir_records.csv"

# ---------- Create File ----------
def create_file():
    if not os.path.exists(FILE):
        with open(FILE, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow([
                "FIR ID",
                "Name",
                "Phone",
                "Crime",
                "Location",
                "Date",
                "Status"
            ])


# ---------- Register FIR ----------
def register_fir():

    create_file()

    fir_id = input("FIR ID: ")
    name = input("Complainant Name: ")
    phone = input("Phone Number: ")
    crime = input("Crime Type: ")
    location = input("Crime Location: ")
    date = input("Date (DD-MM-YYYY): ")
    status = "Pending"

    with open(FILE, "a", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            fir_id,
            name,
            phone,
            crime,
            location,
            date,
            status
        ])

    print("FIR Registered Successfully")


# ---------- View FIR ----------
def view_fir():

    create_file()

    with open(FILE, "r") as f:
        reader = csv.reader(f)

        print("\n========== FIR RECORDS ==========\n")

        for row in reader:
            print(row)


# ---------- Search FIR ----------
def search_fir():

    create_file()

    fir_id = input("Enter FIR ID: ")

    with open(FILE, "r") as f:

        reader = csv.reader(f)

        next(reader)

        for row in reader:

            if row[0] == fir_id:
                print("Record Found")
                print(row)
                return

    print("FIR Not Found")


# ---------- Update FIR ----------
def update_fir():

    create_file()

    fir_id = input("Enter FIR ID: ")

    rows = []

    found = False

    with open(FILE, "r") as f:

        reader = csv.reader(f)

        header = next(reader)

        for row in reader:

            if row[0] == fir_id:

                row[1] = input("New Complainant: ")
                row[2] = input("New Phone: ")
                row[3] = input("New Crime: ")
                row[4] = input("New Location: ")
                row[5] = input("New Date: ")
                row[6] = input("New Status: ")

                found = True

            rows.append(row)

    with open(FILE, "w", newline="") as f:

        writer = csv.writer(f)

        writer.writerow(header)
        writer.writerows(rows)

    if found:
        print("FIR Updated Successfully")
    else:
        print("FIR ID Not Found")


# ---------- Delete FIR ----------
def delete_fir():

    create_file()

    fir_id = input("Enter FIR ID: ")

    rows = []

    found = False

    with open(FILE, "r") as f:

        reader = csv.reader(f)

        header = next(reader)

        for row in reader:

            if row[0] != fir_id:
                rows.append(row)
            else:
                found = True

    with open(FILE, "w", newline="") as f:

        writer = csv.writer(f)

        writer.writerow(header)
        writer.writerows(rows)

    if found:
        print("FIR Deleted Successfully")
    else:
        print("FIR ID Not Found")


# ---------- Pending FIRs ----------
def pending_firs():

    create_file()

    with open(FILE, "r") as f:

        reader = csv.reader(f)

        next(reader)

        pending = [row for row in reader if row[6].lower() == "pending"]

    print("\nPending FIRs")

    if pending:
        for row in pending:
            print(row)
    else:
        
        print("No Pending FIRs")


# ---------- Sort FIRs ----------
def sort_firs():

    create_file()

    with open(FILE, "r") as f:

        reader = csv.reader(f)

        header = next(reader)

        rows = list(reader)

    rows.sort(key=lambda x: x[1].lower())

    print(header)

    for row in rows:
        print(row)


# ---------- FIR Menu ----------
def fir_menu():

    create_file()

    while True:

        print("\n========== FIR MANAGEMENT ==========")
        print("1. Register FIR")
        print("2. View FIR Records")
        print("3. Search FIR")
        print("4. Update FIR")
        print("5. Delete FIR")
        print("6. Pending FIRs")
        print("7. Sort FIRs")
        print("8. Back")

        choice = input("Enter Choice: ")

        if choice == "1":
            register_fir()

        elif choice == "2":
            view_fir()

        elif choice == "3":
            search_fir()

        elif choice == "4":
            update_fir()

        elif choice == "5":
            delete_fir()

        elif choice == "6":
            pending_firs()

        elif choice == "7":
            sort_firs()

        elif choice == "8":
            print("Returning to Main Menu...")
            break

        else:
            print("Invalid Choice")


# ---------- Run Directly ----------
if __name__ == "__main__":
    fir_menu()