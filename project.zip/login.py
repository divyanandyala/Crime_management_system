from login import login
from crime import crime_menu
from fir import fir_menu
from evidence import evidence
from analysis import crime_analysis
