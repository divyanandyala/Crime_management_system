import csv
import os

FILE = "crime_records.csv"

# Create CSV File
def create_file():
    if not os.path.exists(FILE):
        with open(FILE, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["Crime ID", "Name", "Age", "Gender", "Crime", "City"])


# Add Criminal
def add_criminal():
    create_file()

    crime_id = input("Crime ID: ")
    name = input("Name: ")
    age = input("Age: ")
    gender = input("Gender: ")
    crime = input("Crime: ")
    city = input("City: ")

    with open(FILE, "a", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([crime_id, name, age, gender, crime, city])

    print("Record Added Successfully")


# View Criminals
def view_criminals():
    create_file()

    with open(FILE, "r") as f:
        reader = csv.reader(f)

        print("\n----- Criminal Records -----")

        for row in reader:
            print(row)


# Search Criminal
def search_criminal():
    create_file()

    crime_id = input("Enter Crime ID: ")

    with open(FILE, "r") as f:
        reader = csv.reader(f)
        next(reader)

        for row in reader:
            if row[0] == crime_id:
                print("Record Found")
                print(row)
                return

    print("Record Not Found")


# Update Criminal
def update_criminal():
    create_file()

    crime_id = input("Enter Crime ID: ")

    rows = []

    with open(FILE, "r") as f:
        reader = csv.reader(f)
        header = next(reader)

        found = False

        for row in reader:
            if row[0] == crime_id:
                row[1] = input("New Name: ")
                row[2] = input("New Age: ")
                row[3] = input("New Gender: ")
                row[4] = input("New Crime: ")
                row[5] = input("New City: ")
                found = True

            rows.append(row)

    with open(FILE, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(header)
        writer.writerows(rows)

    if found:
        print("Record Updated")
    else:
        print("Crime ID Not Found")


# Delete Criminal
def delete_criminal():
    create_file()

    crime_id = input("Enter Crime ID: ")

    rows = []

    with open(FILE, "r") as f:
        reader = csv.reader(f)
        header = next(reader)

        found = False

        for row in reader:
            if row[0] != crime_id:
                rows.append(row)
            else:
                found = True

    with open(FILE, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(header)
        writer.writerows(rows)

    if found:
        print("Record Deleted")
    else:
        print("Crime ID Not Found")


# Lambda Function
def sort_age():
    create_file()

    with open(FILE, "r") as f:
        reader = csv.reader(f)
        header = next(reader)
        rows = list(reader)

    if len(rows) == 0:
        print("No Records")
        return

    rows.sort(key=lambda x: int(x[2]))

    print(header)

    for row in rows:
        print(row)


# List Comprehension
def criminal_names():
    create_file()

    with open(FILE, "r") as f:
        reader = csv.reader(f)
        next(reader)

        names = [row[1] for row in reader]

    print(names)


# Menu
def crime_menu():

    create_file()

    while True:

        print("\n========== CRIME RECORD MANAGEMENT ==========")
        print("1. Add Criminal")
        print("2. View Criminals")
        print("3. Search Criminal")
        print("4. Update Criminal")
        print("5. Delete Criminal")
        print("6. Sort By Age")
        print("7. Criminal Names")
        print("8. Exit")

        choice = input("Enter Choice: ")

        if choice == "1":
            add_criminal()

        elif choice == "2":
            view_criminals()

        elif choice == "3":
            search_criminal()

        elif choice == "4":
            update_criminal()

        elif choice == "5":
            delete_criminal()

        elif choice == "6":
            sort_age()

        elif choice == "7":
            criminal_names()

        elif choice == "8":
            print("Returning...")
            break

        else:
            print("Invalid Choice")


# Run Directly
if __name__ == "__main__":
    crime_menu()